# Wakanda-for-Unciv
Play as Marvel's greatest civilization in Unciv. Unlock the secrets of the Sacred Mound and conquer the world!
What makes this mod special is that this nation's unique traits (of which it has many) are all up for the stealing. If you conquer the capital city and steal the Sacred Mound, you can seize all of its power for yourself!