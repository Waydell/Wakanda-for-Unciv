Wakanda, Black Panther, Vibranium, Heart-Shaped Herb, Helicarrier, Dora Milaje, T'Challa, and other related terms are property (copyright and/or trademark) of Marvel Comics, used here in compliance with fair use guidelines

From the Noun Project:

Black Panther: [Black Panther by Polina Konkova](https://thenounproject.com/icon/black-panther-4240467/)

Panther Scout: [Panther Paw by Kemesh Maharjan](https://thenounproject.com/term/panther-paw/194071/)

Infiltrator: [spy by Luiz Carvalho](https://thenounproject.com/term/spy/2277455/)

Dora Milaje: [African traditional weapon by Chanut is Industries](https://thenounproject.com/term/african-traditional-weapon/1659392/)

Wakanda Forever: [wakanda forever by Pregenun](https://thenounproject.com/term/wakanda-forever/1677369/)

Secret of Vibranium Alloys: [Science by Mello](https://thenounproject.com/term/science/1676493/)

War Rhino: [Rhinoceros by Martin](https://thenounproject.com/term/rhinoceros/952510/)

White Gorilla: [Gorilla by Yorlmar Campos](https://thenounproject.com/term/gorilla/164028/)

Sacred Mound: [Rock Cairn by Hamish](https://thenounproject.com/term/rock-cairn/631385/)

Secret of Monetary Theory: [coin by Delta](https://thenounproject.com/term/coin/3603657/)

Secret of Antarctic Vibranium: [Antarctica by P Thanga Vignesh](https://thenounproject.com/term/antarctica/612120/)

Vibranium/Secret of Vibranium Power: [Crystal by Martin Delin](https://thenounproject.com/term/crystal/7374/)

Energy Barrier: [dome by Lluisa Iborra](https://thenounproject.com/term/dome/945836/)

Secret of the Heart-Shaped Herb: [linden leaf by Vectors Market](https://thenounproject.com/term/linden-leaf/1882874/)

Helicarrier: [hover by DinosoftLab](https://thenounproject.com/term/hover/1844077/)

Secret of Enlightened Culture: [spirituality by Rflor](https://thenounproject.com/term/spirituality/225580/)

Panther Eyes/Secret of Panther Vision: [eyes by Lee Mette](https://thenounproject.com/term/eyes/16471/)

Panther God Shrine: [Panther by Kemesh Maharjan](https://thenounproject.com/icon/panther-194068/)